# One Month Rails

This is the sample project for
[*One Month Rails*](http://onemonthrails.com)

by [Mattan Griffel](http://mattangriffel.com)